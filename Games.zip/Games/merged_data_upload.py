import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import ast
import json
import mysql.connector

games=pd.read_csv('C:/Users/vicky/OneDrive/Desktop/MiniProject/Miniproject2/games.csv',encoding='latin1')

games_copy=games.copy()

#print(games_copy.head())

def convert_shorthand(val):
    val = val.upper().strip()
    if val.endswith('K'):
        return float(val[:-1]) * 1_000
    elif val.endswith('M'):
        return float(val[:-1]) * 1_000_000
    else:
        return float(val)
games_copy['Times Listed']=games_copy['Times Listed'].apply(convert_shorthand)
games_copy['Plays']=games_copy['Plays'].apply(convert_shorthand)
games_copy['Number of Reviews']=games_copy['Number of Reviews'].apply(convert_shorthand)
games_copy['Playing']=games_copy['Playing'].apply(convert_shorthand)
games_copy['Backlogs']=games_copy['Backlogs'].apply(convert_shorthand)
games_copy['Wishlist']=games_copy['Wishlist'].apply(convert_shorthand)
games_copy['Rating']=games_copy['Rating'].fillna(games_copy['Rating'].mean())

games_copy['Reviews']=games_copy['Reviews'].str.replace('[',"")
games_copy['Reviews']=games_copy['Reviews'].str.replace(']',"")
games_copy['Release Date']=pd.to_datetime(games_copy['Release Date'], errors='coerce')

##print(games_copy[games_copy['Team'].isnull()])
games_copy=games_copy.drop(games_copy.index[649])
games_copy=games_copy.drop(games_copy.index[644])
games_copy = games_copy.dropna(subset=['Release Date'])
games_copy = games_copy.dropna(subset=['Team'])
#print(games_copy)

vgsales=pd.read_csv('C:/Users/vicky/OneDrive/Desktop/MiniProject/Miniproject2/vgsales.csv',encoding='latin1')

vgsales['Year']=vgsales['Year'].fillna(vgsales['Year'].mode()[0])
vgsales['Publisher']=vgsales['Publisher'].fillna(vgsales['Publisher'].mode()[0])
#print(vgsales.isnull().sum())
merged_games_data = pd.merge(games_copy, vgsales, left_on='Title', right_on='Name', how='inner',sort=True)

merged_games_data['Team'] = merged_games_data['Team'].apply(ast.literal_eval)
merged_games_data['Team'] = merged_games_data['Team'].apply(json.dumps)
merged_games_data['Genres'] = merged_games_data['Genres'].apply(ast.literal_eval)
merged_games_data['Genres'] = merged_games_data['Genres'].apply(json.dumps)


#print(merged_games_data[merged_games_data.index[1011]])

conn=mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    autocommit=True,
    database='games'
)

cursor=conn.cursor()

for index, row in merged_games_data.iterrows():

       cursor.execute(
        "INSERT IGNORE INTO merged_data (ID,Title,Release_Date,team,Rating,Times_Listed,Number_of_Reviews,Genres,Summary,Reviews,Plays,Playing,Backlogs,Wishlist,Ranks,Name,Platform,Year,Genre,Publisher,NA_Sales,EU_Sales,JP_Sales,Other_Sales,Global_Sales) " \
        "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
        tuple(row))
    
conn.commit
print("insertion successful")
