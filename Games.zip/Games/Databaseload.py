import pandas as pd
import mysql.connector
import category_encoders as ce
from sklearn.preprocessing import MultiLabelBinarizer
vgsales=pd.read_csv("C:/Users/vicky/OneDrive/Desktop/MiniProject/Miniproject2/vgsales.csv")
#print(vgsales)
#Fill the null year values with mode value
vgsales['Year']=vgsales['Year'].fillna(vgsales['Year'].mode()[0])
# Fill missing 'Publisher' values with the mode
vgsales['Publisher']=vgsales['Publisher'].fillna(vgsales['Publisher'].mode()[0])

print(vgsales.head())

#print(final_encoded_vgsales.info())
#print(vgsales.duplicated().sum())
#print(final_encoded_vgsales.head())'''

#database connection
conn=mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    autocommit=True,
    database='games'
)

cursor=conn.cursor()

for index,rows in vgsales.iterrows():
    #print(rows['Name'])
    cursor.execute(""" insert into vgsales(ID,Name,Platform,Year,Genre,Publisher,NA_Sales,EU_Sales,JP_Sales,Other_Sales,Global_Sales) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                   """,tuple(rows))
    
    
conn.commit()
print("insertion successful")

