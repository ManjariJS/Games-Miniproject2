import pandas as pd
import mysql.connector
import ast
import json

# Load CSV
games_df = pd.read_csv('C:/Users/vicky/OneDrive/Desktop/MiniProject/Miniproject2/games.csv', encoding='latin1')
games_df_copy=games_df.copy()

#function to convert K values to actual float values

   
def convert_shorthand(val):
    val = val.upper().strip()
    if val.endswith('K'):
        return float(val[:-1]) * 1_000
    elif val.endswith('M'):
        return float(val[:-1]) * 1_000_000
    else:
        return float(val)
games_df_copy['Times Listed']=games_df_copy['Times Listed'].apply(convert_shorthand)
games_df_copy['Plays']=games_df_copy['Plays'].apply(convert_shorthand)
games_df_copy['Number of Reviews']=games_df_copy['Number of Reviews'].apply(convert_shorthand)
games_df_copy['Playing']=games_df_copy['Playing'].apply(convert_shorthand)
games_df_copy['Backlogs']=games_df_copy['Backlogs'].apply(convert_shorthand)
games_df_copy['Wishlist']=games_df_copy['Wishlist'].apply(convert_shorthand)

# #Drop the row of Teams column with na value
# #games_df_copy=games_df_copy.drop(games_df_copy.index[1245])

# #print(games_df_copy[games_df_copy['Team'].isnull()])
games_df_copy['Rating']=games_df_copy['Rating'].fillna(games_df_copy['Rating'].mean())
games_df_copy=games_df_copy.drop(games_df_copy.index[1245])
games_df_copy=games_df_copy.drop(games_df_copy.index[649])
#print(games_df_copy[games_df_copy['Summary'].isnull()])
#print(games_df_copy.head())
# games_df_copy=games_df_copy.drop(games_df_copy.index[649])
games_df_copy['Reviews']=games_df_copy['Reviews'].str.replace('[',"")
games_df_copy['Reviews']=games_df_copy['Reviews'].str.replace(']',"")
games_df_copy['Release Date']=pd.to_datetime(games_df_copy['Release Date'], errors='coerce')
#print(games_df_copy.info())

games_df_copy['Release Date']=games_df_copy['Release Date'].fillna(games_df_copy['Release Date'].mean())
#print(games_df_copy[games_df_copy['Release Date'].isnull()])
# #print(games_df_copy.head())
##print(games_df_copy[games_df_copy.isnull()].sum())
# #Table creation and insertion



games_df_copy['Team'] = games_df_copy['Team'].apply(ast.literal_eval)
games_df_copy['Team'] = games_df_copy['Team'].apply(json.dumps)
games_df_copy['Genres'] = games_df_copy['Genres'].apply(ast.literal_eval)
games_df_copy['Genres'] = games_df_copy['Genres'].apply(json.dumps)
print(games_df_copy.head())

conn=mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    autocommit=True,
    database='games'
)

cursor=conn.cursor()

# for index, row in games_df_copy.iterrows():
   
#    cursor.execute(
#         "INSERT INTO Games_Data (ID,Title,Release_Date,team,Rating,Times_Listed,Number_of_Reviews,Genres,Summary,Reviews,Plays,Playing,Backlogs,Wishlist) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
#         tuple(row))
    
# conn.commit
# print("insertion successful")
